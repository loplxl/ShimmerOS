from pathlib import Path
async def getURL():
    return "https://dl.google.com/chrome/install/ChromeStandaloneSetup64.exe",(Path.home() / "Downloads" / "ChromeStandaloneSetup64.exe")