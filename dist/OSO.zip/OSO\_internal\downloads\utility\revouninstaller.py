from pathlib import Path
async def getURL():
    return "https://download.revouninstaller.com/download/revosetup.exe",(Path.home() / "Downloads" / "revosetup.exe")