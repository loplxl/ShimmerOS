from pathlib import Path
async def getURL():
    return "https://net.geo.opera.com/opera_gx/stable/windows",(Path.home() / "Downloads" / "OperaGXSetup.exe")