from pathlib import Path
async def getURL():
    return "https://www.srware.net/downloads/srware_iron64.exe",(Path.home() / "Downloads" / "srware_iron64.exe")