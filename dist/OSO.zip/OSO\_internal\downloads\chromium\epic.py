from pathlib import Path
async def getURL():
    return "https://cdn.epicbrowser.com/winsetup/EpicSetup.exe",(Path.home() / "Downloads" / "EpicSetup.exe")